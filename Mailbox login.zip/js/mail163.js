 window.onload = function() {
    var oSpan = document.getElementById("sp1");
    var oLeb = document.getElementById("lb1");
    var oDiv = document.getElementById("tips");
    var oinp = document.getElementById("inp3");
    var oinp1 = document.getElementById("inp1");
    var oinp2 = document.getElementById("inp2");
    var leb1 = document.getElementById("div2").getElementsByTagName("label")[0];
    var leb2 = document.getElementById("div3").getElementsByTagName("label")[0];
    var oDiv31 = document.getElementById("div31");
    var oDivMenul =document.getElementById("menul");
    var oDivMenur =document.getElementById("menur");
    var oDivmain_function_mail =document.getElementById("main-function-mail");
    var oDivmain_function_barcode =document.getElementById("main-function-barcode");
    var oDivbarcode_div3_div1 =document.getElementById("barcode-div3-div1");
    var oDivbarcode_div3_div2 =document.getElementById("barcode-div3-div2");
    var oDivbarcode_div3_div3 =document.getElementById("barcode-div3-div3");
    var oDivbarcode_div3_wrap =document.getElementById("barcode-div3-wrap");
    var oLeb1 = document.getElementById("lb3");
    var oinp4 = document.getElementById("inp4");
    var oDivBigpic = document.getElementById("bgpic");
    var oDivdiv7_div1 = document.getElementById("div7-div1");
    var aDivBigpica = oDivBigpic.getElementsByTagName("a")[0];
    var oDivdiv6_div1 = document.getElementById("div6-div1");
    var oUl1 = document.getElementById("main-function-mail-ul1");
    var oBtn1 = document.getElementById("but1");
    var i = 0;
    oDivdiv6_div1.onclick = function () {
        oUl1.style.display ="block";
        var aLi = oUl1.getElementsByTagName("li");
        for(i=0;i<aLi.length;i++) {
            aLi[i].onmouseover = function (ev) {
                 this.style.backgroundColor ="pink" ;
                 var oEvent =ev || event;
                 oEvent.cancelBubble = true;
            }
            aLi[i].onmouseout = function (ev) {
                 var oEvent =ev || event;
                 this.style.backgroundColor = '' ;
                 oEvent.cancelBubble = true;
            }
            aLi[i].onclick = function () {
                 oDivdiv6_div1.getElementsByTagName("a")[0].innerHTML=
                     this.getElementsByTagName("a")[0].innerText;
                 // console.log(this.getElementsByTagName("a")[0].innerText);
                 oUl1.style.display ="none";
            }

            }
        oUl1.onmouseover =function () {
            oUl1.style.display ="none";
         }

     }

     setInterval(function () {
         var imgarr1 = ["1.jpg","2.png","3.png","4.png","5.png","6.png"];
         if(i >= imgarr1.length) {i=0;};
         oDivdiv7_div1.style.backgroundImage ='url(./image/' + imgarr1[i]+')';
         i++;
     },60000);
    //大背景图以及颜色变换satart
    setInterval(function () {
        var imgarr = ["promPic.jpg","promPic1.jpg","promPic2.jpg"];
        var colorarr = ["#F4F4F4","#DEF0F2","#F9F9F1"];
        var linkarr = [
            "http://you.163.com/item/detail?id=1197009&_stat_area=mod_1_item_1&_stat_id=1005002&_stat_referer=itemList",
            "https://item.jd.com/4973887.html",
            "http://you.163.com/item/detail?id=1413003&from=web_gg_mail_mailin_0"];

        if(i >= imgarr.length) {i=0;};
        oDivBigpic.style.backgroundImage ='url(./image/' + imgarr[i]+')';
        oDivBigpic.style.backgroundColor =colorarr[i];
        aDivBigpica.href = linkarr[i];
        i++;
    },60000);
     // 大背景图以及颜色变换end
    // 登录框菜单切换start
    oDivbarcode_div3_wrap.onmouseover = function () {
        oDivbarcode_div3_div1.style.display = "none";
        oDivbarcode_div3_div2.style.display = "block";
        oDivbarcode_div3_div3.style.display = "block";
    }
    oDivbarcode_div3_wrap.onmouseout = function () {
        oDivbarcode_div3_div1.style.display = "block";
        oDivbarcode_div3_div2.style.display = "none";
        oDivbarcode_div3_div3.style.display = "none";
     }
    oDivMenul.onmouseover = function () {

        oDivMenul.style.background = "#fff";
        oDivMenur.style.background = "#deecdf";
        oDivmain_function_mail.style.display ="none";
        oDivmain_function_barcode.style.display ="block";
    }
    oDivMenur.onmouseover = function () {
        oDivMenur.style.background = "#fff";
        oDivMenul.style.background = "#deecdf";
        oDivmain_function_mail.style.display ="block";
        oDivmain_function_barcode.style.display ="none";
    }
    // 登录框菜单切换end
    // 账户输入框鉴别start
    oinp1.oninput =function() {
        if(this.value!=="") {
            leb1.style.display = "none";
        }else {
            leb1.style.display = "block";
        }
    }
    // 账户输入框鉴别end
    // 密码输入框鉴别start
    oinp2.onfocus =function() {
        leb2.style.display = "none";
        oDiv31.style.display ="none";
    }
    oinp2.onblur =function() {
        if(oinp2.value=="") {
            leb2.style.display = "block";
        }else {
            if(oinp2.value.length<6 || oinp2.value.length>12) {
                oDiv31.style.display ="block";
            }
        }
    }
    // 密码输入框鉴别end
    oSpan.onmouseover = function() {
        oDiv.style.display = "block"
    }
    oSpan.onmouseout = function() {
        oDiv.style.display = "none";
    }
    oLeb.onclick = function() {
        if(oinp.checked) {
            oinp.checked = false;
        }
        else {
            oinp.checked = true;
        }
    }
     oLeb1.onclick = function() {
         if(oinp4.checked) {
             oinp4.checked = false;
         }
         else {
             oinp4.checked = true;
         }
     }
     // oBtn1.onclick = function () {
     //
     //        if(oinp1.value==""){
     //            oinp1.setCustomValidity("请输入账号！");
     //        }
     //
     //    //
     //    // if(oinp2.value == ""){
     //    //     oinp2.setCustomValidity("请输入密码！");
     //    // }
     // }

 }