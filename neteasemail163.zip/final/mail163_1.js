 window.onload = function() {
            var oSpan = document.getElementById("sp1");
            var oLeb = document.getElementById("lb1");
            var oDiv = document.getElementById("tips");
            var oinp = document.getElementById("inp3");
            var oinp1 = document.getElementById("inp1");
            var oinp2 = document.getElementById("inp2");
            var leb1 = document.getElementById("div2").getElementsByTagName("label")[0];
            var leb2 = document.getElementById("div3").getElementsByTagName("label")[0];
            var oDiv31 = document.getElementById("div31");
            var oDivMenul =document.getElementById("menul");
            var oDivMenur =document.getElementById("menur");
            var oDivmain_function_mail =document.getElementById("main-function-mail");
            var oDivmain_function_barcode =document.getElementById("main-function-barcode");
            var oDivbarcode_div3_div1 =document.getElementById("barcode-div3-div1");
            var oDivbarcode_div3_div2 =document.getElementById("barcode-div3-div2");
            var oDivbarcode_div3_div3 =document.getElementById("barcode-div3-div3");
            var oDivbarcode_div3_wrap =document.getElementById("barcode-div3-wrap");
            var oLeb1 = document.getElementById("lb3");
            var oinp4 = document.getElementById("inp4");

            oDivbarcode_div3_wrap.onmouseover = function () {
                oDivbarcode_div3_div1.style.display = "none";
                oDivbarcode_div3_div2.style.display = "block";
                oDivbarcode_div3_div3.style.display = "block";
            }
            oDivbarcode_div3_wrap.onmouseout = function () {
                oDivbarcode_div3_div1.style.display = "block";
                oDivbarcode_div3_div2.style.display = "none";
                oDivbarcode_div3_div3.style.display = "none";
             }
            oDivMenul.onmouseover = function () {

                oDivMenul.style.background = "#fff";
                oDivMenur.style.background = "#ececec";
                oDivmain_function_mail.style.display ="none";
                oDivmain_function_barcode.style.display ="block";
            }
            oDivMenur.onmouseover = function () {
                oDivMenur.style.background = "#fff";
                oDivMenul.style.background = "#ececec";
                oDivmain_function_mail.style.display ="block";
                oDivmain_function_barcode.style.display ="none";
            }
            oinp1.oninput =function() {
                if(this.value!=="") {
                    leb1.style.display = "none";
				}else {
                    leb1.style.display = "block";
				}
			}
            oinp2.onfocus =function() {
                leb2.style.display = "none";
                oDiv31.style.display ="none";
            }
            oinp2.onblur =function() {
                if(oinp2.value=="") {
                    leb2.style.display = "block";
                }else {
                    if(oinp2.value.length<6 || oinp2.value.length>12) {
                        oDiv31.style.display ="block";
					}
				}
            }
            oSpan.onmouseover = function() {
                oDiv.style.display = "block"
            }
            oSpan.onmouseout = function() {
                oDiv.style.display = "none";
            }
            oLeb.onclick = function() {
                if(oinp.checked) {
                    oinp.checked = false;
                }
                else {
                    oinp.checked = true;
                }
            }
             oLeb1.onclick = function() {
                 if(oinp4.checked) {
                     oinp4.checked = false;
                 }
                 else {
                     oinp4.checked = true;
                 }
             }
        }